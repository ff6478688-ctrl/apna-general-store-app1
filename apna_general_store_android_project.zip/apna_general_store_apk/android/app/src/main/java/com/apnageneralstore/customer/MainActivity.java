package com.apnageneralstore.customer;

import android.app.*; import android.os.*; import android.content.*; import android.graphics.Bitmap; import android.net.Uri; import android.view.*; import android.webkit.*; import java.util.*;

public class MainActivity extends Activity {
  private WebView web;
  private static final String HOME="https://apnacustomerrebuilt-noefdzt4i-apna-general-store.vercel.app/";
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setMediaPlaybackRequiresUserGesture(false); s.setUserAgentString(s.getUserAgentString()+" ApnaGeneralStoreApp/1.0");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,String url){
        if(url.startsWith("upi://")||url.startsWith("intent://")){ try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){} return true; }
        if(url.startsWith("http://")||url.startsWith("https://")){v.loadUrl(url); return true;} return false;
      }
    });
    web.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{ try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){} });
    web.loadUrl(HOME);
  }
  @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
