# Apna General Store — Android APK project

This project wraps the live customer website as a real Android app. It uses the same Supabase backend and supports COD/UPI through the existing customer site. UPI links are handed to installed UPI apps when Android supports the intent.

## Build
Open the `android` folder in Android Studio and build the APK, or run `./gradlew assembleDebug` from the `android` folder.

## GitHub build
Push this folder to a GitHub repository. The included workflow builds a debug APK and publishes it as a workflow artifact.

Package: `com.apnageneralstore.customer`
App name: `Apna General Store`

The app currently points to:
https://apnacustomerrebuilt-noefdzt4i-apna-general-store.vercel.app/
